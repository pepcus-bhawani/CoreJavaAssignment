package spring.core.bhawani.Assignment;

import spring.core.bhawani.Assignment.DB.AddFileDataToDatabase;
import spring.core.bhawani.Assignment.file.FileReadWrite;

public class Demo
{
    public static void main( String[] args )
    {
    	AddFileDataToDatabase addData=new AddFileDataToDatabase();
    	if(addData.addDataToDatabase())
    		System.out.println("********Data Added To DB**********");
    	else
    		System.out.println("*********data adding error*******");
    	
        FileReadWrite flr=new FileReadWrite();
    	if(flr.addDataTOFile())
    	{
    		System.out.println("************Data Added TO file************");
    	
    	}
    	else
    	{
    		System.out.println("*************Data add to file error**************");
    	}
    }
}
