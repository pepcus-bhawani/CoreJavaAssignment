package spring.core.bhawani.Assignment.DB;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.SQLException;
import java.util.Properties;

/**
 * 
 * @author Pepcus.User.Bhawani.Singh
 *
 */
public final class DbConnection {
	
	private static  Connection con=null;
	
	private DbConnection() {}
	
	private Connection  dbConnection() throws SQLException, ClassNotFoundException, IOException
	{
		Properties p=new Properties();
		FileInputStream fin=new FileInputStream("db.property");
		p.load(fin);
		String url=p.getProperty("url");
		String user=p.getProperty("user");
		String pass=p.getProperty("password");
		Class.forName("com.mysql.jdbc.Driver");  
	    con=DriverManager.getConnection(url,user,pass);  

	    return con;   
		
	}
	public static Connection connection() throws ClassNotFoundException, SQLException, IOException  {
		
		if(con==null)
		{
			DbConnection c=new DbConnection();
			con=c.dbConnection();
			return con;
		}
		else
		{
			return con;
		}
			 
		
		}
}
