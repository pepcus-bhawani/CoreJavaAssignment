package spring.core.bhawani.Assignment.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import spring.core.bhawani.Assignment.DB.DbConnection;
/**
 * 
 * @author Pepcus.Bhawani.Singh
 * 
 * class to read data from file 
 *
 */
public class FileReadWrite {
	
	// This method reads data from file and convert data into nested list and return the list.
	public List fileList()
	{
		List l=new ArrayList();
		try {
		      File myObj = new File("E:\\sql_test/text.txt");
		      Scanner myReader = new Scanner(myObj);
		      while (myReader.hasNextLine()) {
		        String data = myReader.nextLine();
		        //String data1=data.replace('|', ',');
		        String[] dataArr=data.split("\\|");
		       // String dataArr[]=data1.split(",");
		        List<String> list=Arrays.asList(dataArr);
		        l.add(list);
		        
		        
		      }
		      System.out.println(l);
		      myReader.close();
		    } catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
		return l;
	}
	
	// method reads data from database and save data to text file
	public boolean addDataTOFile()
	{
		int flag=0;
	    try {
	        File myObj = new File("E:\\sql_test/student.txt");
	        if (myObj.createNewFile()) {
	          System.out.println("File created: " + myObj.getName());
	        } else {
	          System.out.println("File already exists.");
	        }
	        FileWriter myWriter = new FileWriter("E:\\sql_test/student.txt");
	        //myWriter.write("Files in Java might be tricky, but it is fun enough! ");
	        
	        Connection con=DbConnection.connection();
	        Statement stmt=con.createStatement();  
	        ResultSet rs=stmt.executeQuery("select * from student");  
	        while(rs.next())  {
	        String s=(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4)+"  "+rs.getString(5)+"  "+rs.getString(6)+"  "+rs.getString(7)+"  "+rs.getString(8)+"  "+rs.getString(9)+"  "+rs.getString(10)+"  "+rs.getString(11)+"  "+rs.getString(12)+"  "+rs.getString(13)+"  "+rs.getString(14)+"  "+rs.getString(15)+"  "+rs.getString(16)+"  "+rs.getString(17)+"  "+rs.getString(18)+"  "+rs.getString(19)+"  "+rs.getString(20)+"  "+rs.getString(21)+"  "+rs.getString(22)+"  "+rs.getString(23)+"  "+rs.getString(24)+"  "+rs.getString(25)+"  "+rs.getString(26)+"  "+rs.getString(27)+"  "+rs.getString(28)+"  "+rs.getString(29)+"  "+rs.getString(30)+"  "+rs.getString(31));  
	        
	        myWriter.write(s);
	        
	        
	        }
	        con.close();
	        myWriter.close();
	        flag=1;
	      } 
	      catch(IOException e)
	      { 
	    	  e.printStackTrace();
	      }
	      catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();}
	       catch (ClassNotFoundException e) {
	        System.out.println("An error occurred.");
	        e.printStackTrace();
	      }
	    
	    if(flag==1)
	    {
	    	return true;
	    }
	    else
	    {
	    	return false;
	    }

	}


}
