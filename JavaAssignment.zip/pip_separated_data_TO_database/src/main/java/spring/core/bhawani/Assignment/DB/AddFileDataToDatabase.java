package spring.core.bhawani.Assignment.DB;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import spring.core.bhawani.Assignment.file.FileReadWrite;

/**
 * 
 * @author Bhawani Singh
 * 
 * this method save the data present inside the text file
 *
 */
public class AddFileDataToDatabase {
	
	public boolean addDataToDatabase()
	{
		FileReadWrite fl=new FileReadWrite();
		List list=fl.fileList();
		//System.out.println(list);
		int flag=0;
		
		try {
			Connection con=DbConnection.connection();
			PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			for(int i=0;i<list.size();i++) {
			{   int k=0;
				List l =(List) list.get(i);
				for(int j=0;j<l.size();j++)
				{
					String s=(String) l.get(j);
					//System.out.println(s);
					ps.setString(++k,s);
				}
				
				ps.executeUpdate();
				
			}
			  flag=1;
			}
			
			
		} 
		catch(IOException e)
		{
			e.printStackTrace();
		}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
        if(flag ==1)
        return true;
        else
		return false;
		
	}

}
